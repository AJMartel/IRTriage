.       .1111...          | Title: Group Policy Preference Password Finder
    .10000000000011.   .. | Author: Oliver Morton (Sec-1 Ltd) 
 .00              000...  | Email: oliverm-tools@sec-1.com
1                  01..   | Description:
                    ..    | Group Policy Preferences Password Finder.
                   ..     | 
GrimHacker        ..      |
                 ..       |
grimhacker.com  ..        |
@grimhacker    ..         |
------------------------------------------------------------------------------
GP3Finder - Group Policy Preferences Password Finder.
    Copyright (C) 2015  Oliver Morton (Sec-1 Ltd)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

This tool requires the following:
 - Python2.7
 - PyWin32 (if running on Windows)
 - PyCrypto

 
Typical Usage:
    Decrypt a given cpassword:
        gp3finder.py -D CPASSWORD

    The following commands output decrypted cpasswords (from Groups.xml etc)
    and list of xml files that contain the word 'password' (for manual review)
    to file ('gp3finder.out' by default, this can be changed with -o FILE).

    Find and decrypt cpasswords on domain controller automatically:
        gp3finder.py -A -t DOMAIN_CONTROLLER -u DOMAIN\USER
        Password: PASSWORD
    Maps DOMAIN_CONTROLLER's sysvol share with given credentials.

    Find and decrypt cpasswords on the local machine automatically:
        gp3finder.py -A -l
    Searches through "C:\ProgramData\Microsoft\Group Policy\History" (by
    default) this can be changed with -lr PATH
    
    Find and decrypt cpasswords on a remote host:
        gp3finder.py -A -t HOST -u DOMAIN\USER -s C$ -rr "ProgramData\Microsoft\Group Policy\History"

    Find and decrypt cpasswords on hosts specified in a file (one per line):
        gp3finder.py -A -f HOST_FILE -u DOMAIN\USER -s C$ -rr "ProgramData\Microsoft\Group Policy\History"
        
    Note: the user this script is run as must have permission to map/mount
    shares if running against a remote host.

Additional Options:
    See: --help

